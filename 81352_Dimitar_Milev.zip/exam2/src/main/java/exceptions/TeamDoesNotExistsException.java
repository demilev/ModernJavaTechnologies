package exam2.exceptions;

public class TeamDoesNotExistsException extends Exception {

	public TeamDoesNotExistsException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
