package exam1;

public enum CarType {
	SEDAN, HETCHBECK, COMBI, CABRIO
}
