package exam2.exceptions;

public class TeamAlreadyExistsException extends Exception {

	public TeamAlreadyExistsException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
