package exam2.exceptions;

public class NegativePointsException extends Exception {

	public NegativePointsException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
