package exam1;

public class IllegalInputException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IllegalInputException() {
		// TODO Auto-generated constructor stub
	}

	public IllegalInputException(String message) {
		super(message);
	}



}
